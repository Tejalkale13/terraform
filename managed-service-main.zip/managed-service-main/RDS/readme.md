This folder is for RDS monitoring(cpu, memory, disk) terraform script.
