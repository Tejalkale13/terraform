This folder is for EKS monitoring terraform scripts.
