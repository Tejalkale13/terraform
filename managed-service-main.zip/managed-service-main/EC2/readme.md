This folder is for EC2 monitoring terraform scripts, lambda functions, etc.
