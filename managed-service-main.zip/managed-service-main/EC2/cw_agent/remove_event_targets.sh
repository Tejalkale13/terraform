#!/bin/bash

# Function to remove targets from a rule
remove_rule_targets() {
    local rule_name=$1
    echo "Removing targets from rule: $rule_name"
    
    # List targets and remove them
    targets=$(aws events list-targets-by-rule --rule "$rule_name" --query 'Targets[*].Id' --output text)
    if [ ! -z "$targets" ]; then
        aws events remove-targets --rule "$rule_name" --ids $targets
        echo "Removed targets: $targets from rule: $rule_name"
    else
        echo "No targets found for rule: $rule_name"
    fi
}

# List all EventBridge rules with prefix "ec2-" (state monitoring rules)
echo "Processing EC2 state monitoring rules..."
ec2_rules=$(aws events list-rules --name-prefix "ec2-" --query 'Rules[*].Name' --output text)
for rule in $ec2_rules; do
    remove_rule_targets "$rule"
done

# Process disk metric check rule
echo "Processing disk metric check rule..."
remove_rule_targets "disk-metric-check"

echo "All EventBridge rule targets have been removed"
