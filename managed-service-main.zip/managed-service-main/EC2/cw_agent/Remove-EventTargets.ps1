# Function to remove targets from a rule
function Remove-RuleTargets {
    param($RuleName)
    Write-Host "Removing targets from rule: $RuleName"
    
    # List targets and remove them
    $targets = aws events list-targets-by-rule --rule $RuleName --query 'Targets[*].Id' --output text
    if ($targets) {
        aws events remove-targets --rule $RuleName --ids $targets
        Write-Host "Removed targets: $targets from rule: $RuleName"
    } else {
        Write-Host "No targets found for rule: $RuleName"
    }
}

# List all EventBridge rules with prefix "ec2-" (state monitoring rules)
Write-Host "Processing EC2 state monitoring rules..."
$ec2Rules = aws events list-rules --name-prefix "ec2-" --query 'Rules[*].Name' --output text
if ($ec2Rules) {
    $ec2Rules.Split() | ForEach-Object {
        Remove-RuleTargets $_
    }
}

# Process disk metric check rule
Write-Host "Processing disk metric check rule..."
Remove-RuleTargets "disk-metric-check"

Write-Host "All EventBridge rule targets have been removed"
