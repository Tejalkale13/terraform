import boto3
import json
import os
import time
from botocore.exceptions import ClientError

def get_instance_details():
    region = os.environ.get('REGION', 'us-east-1')
    ec2 = boto3.client('ec2', region_name=region)
    instances = []
    
    paginator = ec2.get_paginator('describe_instances')
    for page in paginator.paginate(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}]):
        for reservation in page['Reservations']:
            for instance in reservation['Instances']:
                platform = 'windows' if 'Platform' in instance and instance['Platform'] == 'windows' else 'linux'
                instances.append({
                    'InstanceId': instance['InstanceId'],
                    'Platform': platform
                })
    return instances

def create_disk_alarms(instance, metric_config, sns_topic_arn, thresholds):
    cloudwatch = boto3.client('cloudwatch')
    platform = instance['Platform']
    config = metric_config[platform]
    
    # Get existing metrics to determine actual mount points/drives
    metrics = get_disk_metrics(instance['InstanceId'], platform)
    
    for metric in metrics:
        for threshold in thresholds:
            alarm_name = f"Disk-{instance['InstanceId']}-{metric['path']}-{threshold}"
            
            try:
                cloudwatch.put_metric_alarm(
                    AlarmName=alarm_name,
                    ComparisonOperator='GreaterThanThreshold',
                    EvaluationPeriods=2,
                    MetricName=config['metric_name'],
                    Namespace=config['namespace'],
                    Period=300,
                    Statistic='Average',
                    Threshold=float(threshold),
                    ActionsEnabled=True,
                    AlarmActions=[sns_topic_arn],
                    AlarmDescription=f"Disk usage alarm for {platform} instance {instance['InstanceId']} at {threshold}%",
                    Dimensions=metric['dimensions']
                )
            except ClientError as e:
                print(f"Error creating alarm {alarm_name}: {str(e)}")

def get_disk_metrics(instance_id, platform):
    cloudwatch = boto3.client('cloudwatch')
    metrics = []
    
    if platform == 'windows':
        # Get Windows logical drives
        response = cloudwatch.list_metrics(
            Namespace='CWAgent',
            MetricName='LogicalDisk % Free Space',
            Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}]
        )
        
        for metric in response['Metrics']:
            drive = next((d['Value'] for d in metric['Dimensions'] if d['Name'] == 'instance'), None)
            if drive:
                metrics.append({
                    'path': drive,
                    'dimensions': [
                        {'Name': 'InstanceId', 'Value': instance_id},
                        {'Name': 'instance', 'Value': drive},
                        {'Name': 'objectname', 'Value': 'LogicalDisk'}
                    ]
                })
    else:
        # Get Linux mount points
        response = cloudwatch.list_metrics(
            Namespace='CWAgent',
            MetricName='disk_used_percent',
            Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}]
        )
        
        for metric in response['Metrics']:
            path = next((d['Value'] for d in metric['Dimensions'] if d['Name'] == 'path'), None)
            device = next((d['Value'] for d in metric['Dimensions'] if d['Name'] == 'device'), None)
            fstype = next((d['Value'] for d in metric['Dimensions'] if d['Name'] == 'fstype'), None)
            
            if path and device and fstype:
                metrics.append({
                    'path': path,
                    'dimensions': [
                        {'Name': 'InstanceId', 'Value': instance_id},
                        {'Name': 'path', 'Value': path},
                        {'Name': 'device', 'Value': device},
                        {'Name': 'fstype', 'Value': fstype}
                    ]
                })
    
    return metrics

def create_or_update_alarm(cloudwatch, instance_id, namespace, metric_name, dimensions, threshold, sns_topic_arn):
    try:
        alarm_name = f"DiskSpace-{instance_id}-{dimensions.get('instance', dimensions.get('path', 'unknown'))}"
        
        alarm_config = {
            'AlarmName': alarm_name,
            'ComparisonOperator': 'LessThanThreshold' if 'Free Space' in metric_name else 'GreaterThanThreshold',
            'EvaluationPeriods': 2,
            'MetricName': metric_name,
            'Namespace': namespace,
            'Period': 300,
            'Statistic': 'Average',
            'Threshold': threshold,
            'ActionsEnabled': True,
            'AlarmActions': [sns_topic_arn],
            'OKActions': [sns_topic_arn],
            'AlarmDescription': f'Disk space alarm for {instance_id}',
            'Dimensions': [{'Name': k, 'Value': v} for k, v in dimensions.items()],
            'TreatMissingData': 'breaching'
        }
        
        cloudwatch.put_metric_alarm(**alarm_config)
        print(f"Created/Updated alarm: {alarm_name}")
        
    except ClientError as e:
        print(f"Error creating alarm for {instance_id}: {str(e)}")

def lambda_handler(event, context):
    # Get region from environment variables
    region = os.environ.get('REGION', 'us-east-1')
    
    # Initialize AWS clients with the specified region
    cloudwatch = boto3.client('cloudwatch', region_name=region)
    sns = boto3.client('sns', region_name=region)
    
    # Get configurations from environment variables
    metric_config = json.loads(os.environ['METRIC_CONFIG'])
    sns_topic_arn = os.environ['SNS_TOPIC_ARN']
    thresholds = json.loads(os.environ['ALARM_THRESHOLDS'])
    
    instances = get_instance_details()
    
    for instance in instances:
        instance_id = instance['InstanceId']
        platform = instance['Platform']
        
        config = metric_config[platform]
        threshold = thresholds[platform]
        
        if platform == 'windows':
            # For Windows, create alarm for each drive
            for drive in ['C:', 'D:', 'E:', 'F:']:  # Add more drives if needed
                dimensions = {
                    'InstanceId': instance_id,
                    'instance': drive,
                    'objectname': 'LogicalDisk'
                }
                create_or_update_alarm(
                    cloudwatch,
                    instance_id,
                    config['namespace'],
                    config['metric_name'],
                    dimensions,
                    threshold,
                    sns_topic_arn
                )
        else:
            # For Linux, create alarm for each mount point
            for mount_point in ['/', '/data']:  # Add more mount points if needed
                dimensions = {
                    'InstanceId': instance_id,
                    'path': mount_point,
                    'fstype': 'xfs'  # Adjust if using a different filesystem
                }
                create_or_update_alarm(
                    cloudwatch,
                    instance_id,
                    config['namespace'],
                    config['metric_name'],
                    dimensions,
                    threshold,
                    sns_topic_arn
                )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Disk space alarms updated successfully')
    }
