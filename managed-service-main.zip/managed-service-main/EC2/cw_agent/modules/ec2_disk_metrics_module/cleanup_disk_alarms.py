import boto3
import re

REGION = 'ap-south-1'
cloudwatch = boto3.client('cloudwatch', region_name=REGION)

# Pattern that matches alarm names created by the disk alarm script
# Example: i-0123456789abcdef0__DiskUsedAlarm or i-0123456789abcdef0_C_DiskFreeAlarm
DISK_ALARM_PATTERN = re.compile(r"^i-[a-z0-9]+_.+_Disk(Used|Free)Alarm$")

def lambda_handler(event, context):
    print("Fetching all CloudWatch alarms...")
    paginator = cloudwatch.get_paginator('describe_alarms')
    alarms_to_delete = []

    for page in paginator.paginate():
        for alarm in page['MetricAlarms']:
            name = alarm['AlarmName']
            if DISK_ALARM_PATTERN.match(name):
                alarms_to_delete.append(name)

    if not alarms_to_delete:
        print("✅ No matching disk alarms found for deletion.")
        return {
            'statusCode': 200,
            'body': 'No disk alarms found.'
        }

    print(f"🗑 Deleting {len(alarms_to_delete)} alarm(s)...")
    try:
        # CloudWatch allows up to 100 alarms per delete call
        for i in range(0, len(alarms_to_delete), 100):
            batch = alarms_to_delete[i:i+100]
            cloudwatch.delete_alarms(AlarmNames=batch)
            print(f"  - Deleted batch: {batch}")
    except Exception as e:
        print(f"❌ Failed to delete alarms: {e}")
        return {
            'statusCode': 500,
            'body': f'Error deleting alarms: {e}'
        }

    print("✅ Cleanup complete.")
    return {
        'statusCode': 200,
        'body': f'Deleted {len(alarms_to_delete)} disk alarms successfully.'
    }
