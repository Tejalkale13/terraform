# PowerShell script to install and configure CloudWatch agent
param(
    [string]$ConfigPath,
    [string]$Region
)

# Function to check if CloudWatch agent is installed
function Test-CWAgentInstalled {
    $agent = Get-Service -Name "AmazonCloudWatchAgent" -ErrorAction SilentlyContinue
    return $null -ne $agent
}

# Function to install CloudWatch agent
function Install-CWAgent {
    try {
        $tempDir = "$env:TEMP\AmazonCloudWatchAgent"
        New-Item -ItemType Directory -Force -Path $tempDir | Out-Null
        
        # Download the CloudWatch agent installer
        $installerPath = "$tempDir\AmazonCloudWatchAgentInstaller.msi"
        Invoke-WebRequest -Uri "https://s3.amazonaws.com/amazoncloudwatch-agent/windows/amd64/latest/AmazonCloudWatchAgentInstaller.msi" -OutFile $installerPath
        
        # Install the agent
        Start-Process msiexec.exe -ArgumentList "/i `"$installerPath`" /qn" -Wait
        
        # Clean up
        Remove-Item -Path $tempDir -Recurse -Force
        return $true
    }
    catch {
        Write-Error "Failed to install CloudWatch agent: $_"
        return $false
    }
}

# Function to configure CloudWatch agent
function Configure-CWAgent {
    param([string]$ConfigPath)
    
    try {
        # Wait for the service to be available
        $retries = 0
        while (!(Test-CWAgentInstalled) -and $retries -lt 5) {
            Start-Sleep -Seconds 10
            $retries++
        }
        
        if (!(Test-Path $ConfigPath)) {
            throw "Configuration file not found at $ConfigPath"
        }
        
        # Configure the agent using SSM
        $result = & "$env:ProgramFiles\Amazon\AmazonCloudWatchAgent\amazon-cloudwatch-agent-ctl.ps1" -a fetch-config -m ec2 -s -c "file:$ConfigPath"
        
        if ($LASTEXITCODE -ne 0) {
            throw "Failed to configure CloudWatch agent"
        }
        
        return $true
    }
    catch {
        Write-Error "Failed to configure CloudWatch agent: $_"
        return $false
    }
}

# Main execution
try {
    Write-Output "Starting CloudWatch agent installation and configuration..."
    
    if (!(Test-CWAgentInstalled)) {
        Write-Output "Installing CloudWatch agent..."
        if (!(Install-CWAgent)) {
            throw "Failed to install CloudWatch agent"
        }
    }
    
    Write-Output "Configuring CloudWatch agent..."
    if (Configure-CWAgent -ConfigPath $ConfigPath) {
        Write-Output "CloudWatch agent successfully installed and configured"
        exit 0
    }
    else {
        throw "Failed to configure CloudWatch agent"
    }
}
catch {
    Write-Error "Error: $_"
    exit 1
}
