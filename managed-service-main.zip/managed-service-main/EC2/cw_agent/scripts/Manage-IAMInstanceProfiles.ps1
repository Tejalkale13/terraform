param(
    [Parameter(Mandatory=$true)]
    [string]$InstanceId,
    [Parameter(Mandatory=$true)]
    [string]$RoleName
)

function Wait-ForProfileCreation {
    param([string]$ProfileName)
    
    $maxAttempts = 10
    $attempt = 0
    $created = $false
    
    do {
        $attempt++
        try {
            $profile = aws iam get-instance-profile --instance-profile-name $ProfileName 2>$null
            if ($profile) {
                Write-Output "Profile $ProfileName exists"
                $created = $true
                break
            }
        }
        catch {
            Write-Output "Waiting for profile creation... (Attempt $attempt of $maxAttempts)"
            Start-Sleep -Seconds 5
        }
    } while ($attempt -lt $maxAttempts -and -not $created)
    
    return $created
}

function Wait-ForProfileAssociation {
    param(
        [string]$InstanceId,
        [string]$ProfileName
    )
    
    $maxAttempts = 12
    $attempt = 0
    $associated = $false
    
    do {
        $attempt++
        $association = aws ec2 describe-iam-instance-profile-associations --filters "Name=instance-id,Values=$InstanceId" "Name=state,Values=associated" | ConvertFrom-Json
        
        if ($association.IamInstanceProfileAssociations.Count -gt 0) {
            $currentProfile = $association.IamInstanceProfileAssociations[0].IamInstanceProfile.Arn
            if ($currentProfile -like "*$ProfileName") {
                Write-Output "Profile $ProfileName successfully associated with instance $InstanceId"
                $associated = $true
                break
            }
        }
        
        Write-Output "Waiting for profile association... (Attempt $attempt of $maxAttempts)"
        Start-Sleep -Seconds 10
    } while ($attempt -lt $maxAttempts -and -not $associated)
    
    return $associated
}

# Main execution
$ExpectedProfile = "CWAgent-" + $InstanceId.Replace("-", "").Substring($InstanceId.Length - 8)
Write-Output "Managing IAM instance profile for instance $InstanceId"
Write-Output "Expected profile name: $ExpectedProfile"

# Check if profile exists
try {
    $profileExists = $null -ne (aws iam get-instance-profile --instance-profile-name $ExpectedProfile 2>$null)
}
catch {
    $profileExists = $false
}

# Create profile if it doesn't exist
if (-not $profileExists) {
    Write-Output "Creating new instance profile $ExpectedProfile"
    try {
        aws iam create-instance-profile --instance-profile-name $ExpectedProfile
        if (-not (Wait-ForProfileCreation -ProfileName $ExpectedProfile)) {
            throw "Failed to create instance profile after multiple attempts"
        }
        
        Write-Output "Adding role $RoleName to profile $ExpectedProfile"
        aws iam add-role-to-instance-profile --instance-profile-name $ExpectedProfile --role-name $RoleName
        Start-Sleep -Seconds 10
    }
    catch {
        Write-Error "Failed to create or configure instance profile: $_"
        exit 1
    }
}

# Check current instance association
$currentAssociation = aws ec2 describe-iam-instance-profile-associations --filters "Name=instance-id,Values=$InstanceId" | ConvertFrom-Json

# Remove existing association if it doesn't match expected profile
if ($currentAssociation.IamInstanceProfileAssociations.Count -gt 0) {
    $associationId = $currentAssociation.IamInstanceProfileAssociations[0].AssociationId
    $currentProfile = $currentAssociation.IamInstanceProfileAssociations[0].IamInstanceProfile.Arn
    
    if ($currentProfile -notlike "*$ExpectedProfile") {
        Write-Output "Removing existing profile association"
        aws ec2 disassociate-iam-instance-profile --association-id $associationId
        Start-Sleep -Seconds 10
    }
    else {
        Write-Output "Correct profile already associated"
        exit 0
    }
}

# Associate new profile
Write-Output "Associating profile $ExpectedProfile with instance $InstanceId"
try {
    aws ec2 associate-iam-instance-profile --instance-id $InstanceId --iam-instance-profile Name=$ExpectedProfile
    
    if (Wait-ForProfileAssociation -InstanceId $InstanceId -ProfileName $ExpectedProfile) {
        Write-Output "Successfully associated profile $ExpectedProfile with instance $InstanceId"
    }
    else {
        throw "Profile association did not complete within expected time"
    }
}
catch {
    Write-Error "Failed to associate instance profile: $_"
    exit 1
}
